package com.example.coffeeshop

import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.setPadding

class MainActivity : AppCompatActivity() {

    private lateinit var frame: FrameLayout
    private lateinit var cart: MutableMap<String, Int>
    private lateinit var lastOrder: MutableMap<String, Int>
    private lateinit var viewCartBtn: Button

    data class MenuItem(val name: String, val price: Int, val imageRes: Int)

    private val items = listOf(
        MenuItem("Espresso", 40, R.drawable.espresso),
        MenuItem("Cappuccino", 60, R.drawable.cappuccino),
        MenuItem("Latte", 70, R.drawable.latte),
        MenuItem("Mocha", 80, R.drawable.mocha),
        MenuItem("Americano", 50, R.drawable.americano),
        MenuItem("Black Coffee", 30, R.drawable.black_coffee),
        MenuItem("Cold Brew", 90, R.drawable.cold_brew),
        MenuItem("Flat White", 65, R.drawable.flat_white),
        MenuItem("Biscuits", 20, R.drawable.cookies),
        MenuItem("Cake", 40, R.drawable.cake)
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        cart = mutableMapOf()
        lastOrder = mutableMapOf()
        frame = FrameLayout(this).apply {
            id = View.generateViewId()
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
        }
        setContentView(frame)
        showLoginPage()
    }

    private fun showLoginPage() {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(60)
            setBackgroundResource(R.drawable.background_image_resized)
        }

        val username = EditText(this).apply {
            hint = getString(R.string.username_hint)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(0, 16, 0, 16)
            }
        }

        val password = EditText(this).apply {
            hint = getString(R.string.password_hint)
            inputType = android.text.InputType.TYPE_CLASS_TEXT or
                    android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(0, 16, 0, 16)
            }
        }

        val loginBtn = Button(this).apply {
            text = getString(R.string.btn_login)
            setBackgroundColor(ContextCompat.getColor(this@MainActivity, R.color.purple_500))
            setTextColor(Color.WHITE)
            setPadding(20, 20, 20, 20)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            setOnClickListener {
                if (username.text.toString().isNotEmpty() && password.text.toString().isNotEmpty()) {
                    showMenuPage()
                } else {
                    Toast.makeText(
                        this@MainActivity,
                        getString(R.string.enter_login_details),
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        }

        layout.addView(TextView(this).apply {
            text = getString(R.string.login_title)
            textSize = 24f
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 32)
        })
        layout.addView(username)
        layout.addView(password)
        layout.addView(loginBtn)

        frame.removeAllViews()
        frame.addView(layout)
    }

    private fun showMenuPage() {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(30)
            setBackgroundResource(R.drawable.background_image_resized)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.MATCH_PARENT
            )
        }

        layout.addView(TextView(this).apply {
            text = getString(R.string.menu_title)
            textSize = 24f
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 20)
        })

        val scrollView = ScrollView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                weight = 1f
            }
        }

        val innerLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            setPadding(20)
        }

        for (item in items) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(20)
                gravity = Gravity.CENTER_VERTICAL
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply {
                    setMargins(0, 8, 0, 8)
                }
            }

            val image = ImageView(this).apply {
                setImageResource(item.imageRes)
                layoutParams = LinearLayout.LayoutParams(150, 150).apply {
                    setMargins(0, 0, 16, 0)
                }
            }

            val infoLayout = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(
                    0,
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    1f
                )
            }

            val nameText = TextView(this).apply {
                text = getString(R.string.item_price, item.name, item.price)
                textSize = 18f
                setPadding(0, 0, 0, 8)
            }

            val quantityPicker = NumberPicker(this).apply {
                minValue = 1
                maxValue = 10
                value = 1
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
            }

            val addBtn = Button(this).apply {
                text = getString(R.string.btn_add)
                setBackgroundColor(ContextCompat.getColor(this@MainActivity, R.color.teal_700))
                setTextColor(Color.WHITE)
                setPadding(16, 8, 16, 8)
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply {
                    setMargins(16, 0, 0, 0)
                }
                setOnClickListener {
                    val qty = quantityPicker.value
                    cart[item.name] = cart.getOrDefault(item.name, 0) + qty
                    Toast.makeText(
                        this@MainActivity,
                        getString(R.string.added, qty, item.name),
                        Toast.LENGTH_SHORT
                    ).show()
                    updateCartButton()
                }
            }

            infoLayout.addView(nameText)
            infoLayout.addView(quantityPicker)

            row.addView(image)
            row.addView(infoLayout)
            row.addView(addBtn)

            innerLayout.addView(row)
        }

        scrollView.addView(innerLayout)
        layout.addView(scrollView)

        val btnLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 20, 0, 0)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }

        viewCartBtn = Button(this).apply {
            updateCartButton()
            setBackgroundColor(ContextCompat.getColor(this@MainActivity, R.color.purple_500))
            setTextColor(Color.WHITE)
            setPadding(20, 20, 20, 20)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(0, 16, 0, 16)
            }
            setOnClickListener {
                if (cart.isNotEmpty()) {
                    showCartPage()
                } else {
                    Toast.makeText(
                        this@MainActivity,
                        getString(R.string.cart_empty),
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        }

        btnLayout.addView(viewCartBtn)

        btnLayout.addView(Button(this).apply {
            text = getString(R.string.btn_view_last_order_summary)
            setBackgroundColor(ContextCompat.getColor(this@MainActivity, R.color.teal_700))
            setTextColor(Color.WHITE)
            setPadding(20, 20, 20, 20)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(0, 0, 0, 16)
            }
            setOnClickListener { showLastOrderSummaryPage() }
        })

        layout.addView(btnLayout)

        frame.removeAllViews()
        frame.addView(layout)
    }

    private fun updateCartButton() {
        if (::viewCartBtn.isInitialized) {
            viewCartBtn.text = if (cart.isNotEmpty()) {
                getString(R.string.btn_view_cart, cart.values.sum())
            } else {
                getString(R.string.btn_view_cart_default)
            }
        }
    }

    private fun showCartPage() {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(30)
            setBackgroundResource(R.drawable.background_image_resized)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.MATCH_PARENT
            )
        }

        layout.addView(TextView(this).apply {
            text = getString(R.string.cart_title)
            textSize = 24f
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 20)
        })

        if (cart.isEmpty()) {
            layout.addView(TextView(this).apply {
                text = getString(R.string.cart_empty)
                textSize = 18f
                setPadding(0, 20, 0, 20)
                gravity = Gravity.CENTER
            })
        } else {
            val scrollView = ScrollView(this).apply {
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply {
                    weight = 1f
                }
            }

            val innerLayout = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
            }

            for ((name, qty) in cart) {
                innerLayout.addView(TextView(this).apply {
                    text = getString(R.string.cart_item_text, name, qty)
                    textSize = 18f
                    setPadding(0, 10, 0, 10)
                })
            }

            scrollView.addView(innerLayout)
            layout.addView(scrollView)

            layout.addView(Button(this).apply {
                text = getString(R.string.btn_order_summary)
                setBackgroundColor(ContextCompat.getColor(this@MainActivity, R.color.purple_500))
                setTextColor(Color.WHITE)
                setPadding(20, 20, 20, 20)
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply {
                    setMargins(0, 20, 0, 0)
                }
                setOnClickListener { showOrderSummaryPage() }
            })
        }

        layout.addView(Button(this).apply {
            text = getString(R.string.btn_back_to_menu)
            setBackgroundColor(ContextCompat.getColor(this@MainActivity, R.color.teal_700))
            setTextColor(Color.WHITE)
            setPadding(20, 20, 20, 20)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(0, 20, 0, 0)
            }
            setOnClickListener { showMenuPage() }
        })

        frame.removeAllViews()
        frame.addView(layout)
    }

    private fun showLastOrderSummaryPage() {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(30)
            setBackgroundResource(R.drawable.background_image_resized)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.MATCH_PARENT
            )
        }

        layout.addView(TextView(this).apply {
            text = getString(R.string.last_order_summary)
            textSize = 24f
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 20)
        })

        if (lastOrder.isEmpty()) {
            layout.addView(TextView(this).apply {
                text = getString(R.string.no_past_order)
                textSize = 18f
                setPadding(0, 20, 0, 20)
                gravity = Gravity.CENTER
            })
        } else {
            var total = 0
            for ((name, qty) in lastOrder) {
                val price = items.find { it.name == name }?.price ?: 0
                val subtotal = qty * price
                total += subtotal
                layout.addView(TextView(this).apply {
                    text = getString(R.string.item_qty_subtotal, name, qty, subtotal)
                    textSize = 18f
                    setPadding(0, 10, 0, 10)
                })
            }
            layout.addView(TextView(this).apply {
                text = getString(R.string.total_bill, total)
                textSize = 20f
                setPadding(0, 20, 0, 10)
            })
        }

        layout.addView(Button(this).apply {
            text = getString(R.string.btn_back_to_menu)
            setBackgroundColor(ContextCompat.getColor(this@MainActivity, R.color.teal_700))
            setTextColor(Color.WHITE)
            setPadding(20, 20, 20, 20)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(0, 20, 0, 0)
            }
            setOnClickListener { showMenuPage() }
        })

        frame.removeAllViews()
        frame.addView(layout)
    }

    private fun showOrderSummaryPage() {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(30)
            setBackgroundResource(R.drawable.background_image_resized)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.MATCH_PARENT
            )
        }

        layout.addView(TextView(this).apply {
            text = getString(R.string.order_summary)
            textSize = 24f
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 20)
        })

        layout.addView(TextView(this).apply {
            text = getString(R.string.table_header_format,
                getString(R.string.items_header),
                getString(R.string.quantity_header),
                getString(R.string.price_header))
            textSize = 18f
            setPadding(0, 20, 0, 10)
            gravity = Gravity.CENTER
        })

        var total = 0
        for ((name, qty) in cart) {
            val price = items.find { it.name == name }?.price ?: 0
            val subtotal = qty * price
            total += subtotal
            layout.addView(TextView(this).apply {
                text = getString(R.string.item_qty_subtotal, name, qty, subtotal)
                textSize = 18f
                setPadding(0, 10, 0, 10)
            })
        }

        layout.addView(TextView(this).apply {
            text = getString(R.string.total_bill, total)
            textSize = 20f
            setPadding(0, 20, 0, 10)
        })

        layout.addView(Button(this).apply {
            text = getString(R.string.btn_place_order)
            setBackgroundColor(ContextCompat.getColor(this@MainActivity, R.color.purple_500))
            setTextColor(Color.WHITE)
            setPadding(20, 20, 20, 20)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(0, 20, 0, 0)
            }
            setOnClickListener {
                lastOrder.clear()
                lastOrder.putAll(cart)
                cart.clear()
                updateCartButton()
                Toast.makeText(
                    this@MainActivity,
                    getString(R.string.order_placed_success),
                    Toast.LENGTH_SHORT
                ).show()
                showFinalOrderPage()
            }
        })

        frame.removeAllViews()
        frame.addView(layout)
    }

    private fun showFinalOrderPage() {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(30)
            setBackgroundResource(R.drawable.background_image_resized)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.MATCH_PARENT
            )
        }

        layout.addView(TextView(this).apply {
            text = getString(R.string.order_placed_success)
            textSize = 24f
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 20)
        })

        layout.addView(TextView(this).apply {
            text = getString(R.string.order_summary)
            textSize = 20f
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 20)
        })

        var total = 0
        for ((name, qty) in lastOrder) {
            val price = items.find { it.name == name }?.price ?: 0
            val subtotal = qty * price
            total += subtotal
            layout.addView(TextView(this).apply {
                text = getString(R.string.item_qty_subtotal, name, qty, subtotal)
                textSize = 18f
                gravity = Gravity.CENTER
                setPadding(0, 10, 0, 10)
            })
        }

        layout.addView(TextView(this).apply {
            text = getString(R.string.total_bill, total)
            textSize = 20f
            gravity = Gravity.CENTER
            setPadding(0, 20, 0, 20)
        })

        layout.addView(Button(this).apply {
            text = getString(R.string.btn_back_to_menu)
            setBackgroundColor(ContextCompat.getColor(this@MainActivity, R.color.teal_700))
            setTextColor(Color.WHITE)
            setPadding(20, 20, 20, 20)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(0, 20, 0, 0)
            }
            setOnClickListener { showMenuPage() }
        })

        frame.removeAllViews()
        frame.addView(layout)
    }
}